package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Persona persona = new Persona();
        Scanner keys = new Scanner(System.in);
        int i = 0;
        String nombre;
        String apellido;
        String fNacimiento;

        Persona[] listado = new Persona[3];

        for (Persona p : listado){
            System.out.println("INGRESE NOMBRE, APELLIDO y FECHA DE NACIMIENTO DE LA PERSONA:");
            nombre = keys.next();
            apellido = keys.next();
            fNacimiento = keys.next();
            p = new Persona(nombre, apellido,fNacimiento);
            listado[i] = p;
            System.out.println("Siguiente Persona...");
            i++;
        }
        //System.out.println(persona.getNombre());
        //System.out.println(persona.getApellido());
        //System.out.println(persona.getFechaDeNacimiento());
        //persona.saludar();
        persona.mostrarLista(listado);
    }
}
/*
* 1. Crear un proyecto nuevo mediante Maven.
* 2. Agregar la dependencia necesaria para utilizar Lombok
* 3. Crear un programa Java que pida por consola:

        ? Nombre, Apellido y Fecha de nacimiento de una persona.
        ? Estos datos deben ser guardados en una instancia de una clase Persona utilizando los setters generados por Lombok.
        ! IMPORTANTE: el programa debe permitir cargar varias personas y también debe ofrecer la posibilidad
        !             de listar a todas las personas por pantalla (utilizar los getters generados por Lombok).
* 4. Generar un archivo “jar” del proyecto implementado. Ejecutarlo desde la terminal del Sistema Operativo.
 */